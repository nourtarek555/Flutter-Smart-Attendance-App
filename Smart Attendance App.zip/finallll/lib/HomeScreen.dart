import 'package:finallll/LoginScreen.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'Attendance.dart';
import 'AttendanceRecordsScreen.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final List<String> _courses = [
    'Transmission and Switching',
    'Network Lab',
    'Computer System Architecture',
    'Channel Coding',
    'Network Protocols',
    'Modelling and Simulation',
  ];

  String? _selectedCourse;
  String userEmail = '';
  String _statusMessage = '';

  @override
  void initState() {
    super.initState();
    _requestPermissions();
    _loadUserEmail();
  }

  Future<void> _requestPermissions() async {
    await [
      Permission.bluetooth,
      Permission.bluetoothScan,
      Permission.bluetoothConnect,
      Permission.locationWhenInUse,
    ].request();
  }

  void _loadUserEmail() {
    final user = FirebaseAuth.instance.currentUser;
    setState(() {
      userEmail = user?.email ?? 'User';
    });
  }

  void _logout() async {
    await FirebaseAuth.instance.signOut();
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const LoginScreen()),
    );
  }

  Future<Map<String, dynamic>?> _fetchCourseData() async {
    if (_selectedCourse == null) return null;

    final query = await FirebaseFirestore.instance
        .collection('courses')
        .where('courseName', isEqualTo: _selectedCourse)
        .limit(1)
        .get();

    if (query.docs.isEmpty) return null;
    return query.docs.first.data();
  }

  Future<bool> _isClassTime(Map<String, dynamic> courseData) async {
    final now = DateTime.now();
    final today = DateFormat('EEEE').format(now);

    final String classDay = courseData['dayOfWeek'] ?? '';
    final String startTime = courseData['startTime'] ?? '';
    final String endTime = courseData['endTime'] ?? '';

    if (classDay.isEmpty || startTime.isEmpty || endTime.isEmpty) {
      setState(() => _statusMessage = 'COURSE DATA INCOMPLETE.');
      return false;
    }

    final fmt = DateFormat('HH:mm');
    final start = fmt.parse(startTime);
    final end = fmt.parse(endTime);

    final startDT = DateTime(now.year, now.month, now.day, start.hour, start.minute);
    final endDT = DateTime(now.year, now.month, now.day, end.hour, end.minute);

    final isCorrectDay = today == classDay;
    final isWithinTime = now.isAfter(startDT) && now.isBefore(endDT);

    if (!isCorrectDay || !isWithinTime) {
      setState(() => _statusMessage = 'CLASS NOT IN SESSION');
      return false;
    }

    return true;
  }

  Future<void> scanAndCheckDevice() async {
    if (_selectedCourse == null) {
      setState(() => _statusMessage = 'PLEASE SELECT A COURSE TO TAKE ATTENDANCE');
      return;
    }

    setState(() => _statusMessage = 'FETCHING COURSE DATA...');
    final courseData = await _fetchCourseData();
    if (courseData == null) {
      setState(() => _statusMessage = 'COURSE DATA NOT FOUND');
      return;
    }

    final beaconMac = courseData['beaconUUID'];
    if (beaconMac == null || beaconMac == '') {
      setState(() => _statusMessage = 'COURSE DATA INCOMPLETE');
      return;
    }

    final classInSession = await _isClassTime(courseData);
    if (!classInSession) return;

    setState(() => _statusMessage = 'SCANNING FOR DEVICES...');
    List<ScanResult> results = [];
    final scanSub = FlutterBluePlus.onScanResults.listen((r) => results = r);

    await FlutterBluePlus.startScan();
    await Future.delayed(const Duration(seconds: 8));
    await FlutterBluePlus.stopScan();
    await scanSub.cancel();

    ScanResult? beacon;
    try {
      beacon = results.firstWhere((r) => r.device.id.toString() == beaconMac);
    } catch (_) {
      beacon = null;
    }

    if (beacon == null || beacon.rssi < -70) {
      setState(() => _statusMessage = 'BEACON NOT IN RANGE');
      return;
    }

    setState(() => _statusMessage = 'BEACON DETECTED. MONITORING FOR 2 MINUTES...');
    DateTime lastSeen = DateTime.now();
    bool beaconLeftTooLong = false;

    final monitorSub = FlutterBluePlus.onScanResults.listen((scanList) {
      final found = scanList.any((r) => r.device.id.toString() == beaconMac && r.rssi >= -70);
      final now = DateTime.now();
      if (found) {
        lastSeen = now;
      } else {
        if (now.difference(lastSeen).inSeconds > 20) {
          beaconLeftTooLong = true;
        }
      }
    });

    await FlutterBluePlus.startScan();
    await Future.delayed(const Duration(minutes: 2));
    await FlutterBluePlus.stopScan();
    await monitorSub.cancel();

    if (beaconLeftTooLong) {
      setState(() => _statusMessage = 'BEACON DISCONNECTED');
      return;
    }

    await FirebaseFirestore.instance.collection('attendances').add({
      'studentEmail': userEmail,
      'courseName': _selectedCourse,
      'timestamp': FieldValue.serverTimestamp(),
      'rssi': beacon.rssi,
      'status': 'Attended',
    });

    setState(() => _statusMessage = 'ATTENDANCE TAKEN!');
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => Attendance(
          courseID: _selectedCourse!,
          rssi: beacon!.rssi,
          timeStamp: DateTime.now(),
          BeaconMACAddress: beacon.device.id.toString(),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext c) {
    return Scaffold(
      backgroundColor: Colors.pink[50],
      appBar: AppBar(
        leading: const SizedBox(),
        backgroundColor: Colors.deepOrange,
        title: Text(
          'WELCOME, ${userEmail.toUpperCase()}',
          style: GoogleFonts.poppins(fontWeight: FontWeight.bold, color: Colors.white),
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(24),
          ),
          child: ListView(
            children: [
              Center(
                child: Text(
                  'ATTENDANCE ASSISTANCE',
                  style: GoogleFonts.poppins(fontSize: 28, fontWeight: FontWeight.bold),
                ),
              ),
              const SizedBox(height: 30),
              Text('PICK A COURSE:',
                  style: GoogleFonts.poppins(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              DropdownButtonFormField<String>(
                value: _selectedCourse,
                hint: Text('SELECT COURSE',
                    style: GoogleFonts.poppins(fontWeight: FontWeight.bold)),
                decoration: const InputDecoration(
                    border: OutlineInputBorder(), filled: true, fillColor: Colors.white),
                items: _courses
                    .map((c) => DropdownMenuItem(
                  value: c,
                  child: Text(c.toUpperCase(),
                      style: GoogleFonts.poppins(fontWeight: FontWeight.bold)),
                ))
                    .toList(),
                onChanged: (v) => setState(() {
                  _selectedCourse = v;
                  _statusMessage = '';
                }),
              ),
              const SizedBox(height: 30),
              ElevatedButton.icon(
                onPressed: scanAndCheckDevice,
                icon: const Icon(Icons.wifi_tethering, color: Colors.black),
                label: Text('TAKE ATTENDANCE',
                    style: GoogleFonts.poppins(
                        fontSize: 20, fontWeight: FontWeight.bold, color: Colors.black)),
                style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.deepOrange,
                    padding: const EdgeInsets.symmetric(vertical: 22)),
              ),
              const SizedBox(height: 16),
              ElevatedButton.icon(
                onPressed: () => Navigator.push(
                    c,
                    MaterialPageRoute(
                        builder: (_) => AttendanceRecordsScreen(userEmail: userEmail))),
                icon: const Icon(Icons.list_alt, color: Colors.black),
                label: Text('ATTENDANCE RECORDS',
                    style: GoogleFonts.poppins(
                        fontSize: 20, fontWeight: FontWeight.bold, color: Colors.black)),
                style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.deepOrange,
                    padding: const EdgeInsets.symmetric(vertical: 22)),
              ),
              const SizedBox(height: 16),
              ElevatedButton.icon(
                onPressed: _logout,
                icon: const Icon(Icons.logout, color: Colors.black),
                label: Text('LOG OUT',
                    style: GoogleFonts.poppins(
                        fontSize: 20, fontWeight: FontWeight.bold, color: Colors.black)),
                style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red[800],
                    padding: const EdgeInsets.symmetric(vertical: 22)),
              ),
              const SizedBox(height: 30),
              if (_statusMessage.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 20),
                  child: Text(_statusMessage.toUpperCase(),
                      style: GoogleFonts.poppins(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: _statusMessage.contains('TOO FAR') ||
                              _statusMessage.contains('DISCONNECTED')
                              ? Colors.red
                              : _statusMessage.contains('TAKEN')
                              ? Colors.green
                              : Colors.black),
                      textAlign: TextAlign.center),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
