import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class Attendance extends StatelessWidget {
  String courseID;
  DateTime timeStamp;
  int rssi;
  String BeaconMACAddress;

  Attendance({
    super.key,
    required this.courseID,
    required this.rssi,
    required this.timeStamp,
    required this.BeaconMACAddress,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.pink[50], // Light pink background
      appBar: AppBar(
        title: Text(
          'ATTENDANCE RECORD',
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.bold,
            fontSize: 22,
            letterSpacing: 1.5,
          ),
        ),
        backgroundColor: Colors.deepOrange, // Dark Orange color
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Container(
            width: 400, // Wider box to stretch more
            padding: const EdgeInsets.symmetric(
              horizontal: 24.0,
              vertical: 16.0,
            ),
            decoration: BoxDecoration(
              color: Colors.white, // White box background
              borderRadius: BorderRadius.circular(16.0),
              boxShadow: [
                BoxShadow(
                  color: Colors.black26,
                  blurRadius: 8.0,
                  offset: Offset(0, 4),
                ),
              ],
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text(
                  'COURSE ID:',
                  style: GoogleFonts.poppins(
                    fontWeight: FontWeight.bold,
                    fontSize: 24,
                    letterSpacing: 1.5,
                    color: Colors.black,
                    decoration:
                        TextDecoration.underline, // Underline the label only
                  ),
                  textAlign: TextAlign.center,
                ),
                Text(
                  '$courseID',
                  style: GoogleFonts.poppins(
                    fontWeight: FontWeight.bold,
                    fontSize: 24,
                    letterSpacing: 1.5,
                    color: Colors.black,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 20),
                // Text(
                //   'CLASS ID:',
                //   style: GoogleFonts.poppins(
                //     fontWeight: FontWeight.bold,
                //     fontSize: 24,
                //     letterSpacing: 1.5,
                //     color: Colors.black,
                //     decoration:
                //         TextDecoration.underline, // Underline the label only
                //   ),
                //   textAlign: TextAlign.center,
                // ),
                // Text(
                //   'A1',
                //   style: GoogleFonts.poppins(
                //     fontWeight: FontWeight.bold,
                //     fontSize: 24,
                //     letterSpacing: 1.5,
                //     color: Colors.black,
                //   ),
                //   textAlign: TextAlign.center,
                // ),
                const SizedBox(height: 20),
                Text(
                  'TIMESTAMP:',
                  style: GoogleFonts.poppins(
                    fontWeight: FontWeight.bold,
                    fontSize: 24,
                    letterSpacing: 1.5,
                    color: Colors.black,
                    decoration:
                        TextDecoration.underline, // Underline the label only
                  ),
                  textAlign: TextAlign.center,
                ),
                Text(
                  '${DateTime.now()}',
                  style: GoogleFonts.poppins(
                    fontWeight: FontWeight.bold,
                    fontSize: 24,
                    letterSpacing: 1.5,
                    color: Colors.black,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 20),
                Text(
                  'RSSI:',
                  style: GoogleFonts.poppins(
                    fontWeight: FontWeight.bold,
                    fontSize: 24,
                    letterSpacing: 1.5,
                    color: Colors.black,
                    decoration:
                    TextDecoration.underline, // Underline the label only
                  ),
                  textAlign: TextAlign.center,
                ),
                Text(
                  '${rssi}',
                  style: GoogleFonts.poppins(
                    fontWeight: FontWeight.bold,
                    fontSize: 24,
                    letterSpacing: 1.5,
                    color: Colors.black,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 20),
                Text(
                  'UUID:',
                  style: GoogleFonts.poppins(
                    fontWeight: FontWeight.bold,
                    fontSize: 24,
                    letterSpacing: 1.5,
                    color: Colors.black,
                    decoration:
                    TextDecoration.underline, // Underline the label only
                  ),
                  textAlign: TextAlign.center,
                ),
                Text(
                  '${BeaconMACAddress.toString()}',
                  style: GoogleFonts.poppins(
                    fontWeight: FontWeight.bold,
                    fontSize: 24,
                    letterSpacing: 1.5,
                    color: Colors.black,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 40),
                ElevatedButton(
                  onPressed: () {
                    Navigator.pop(
                      context,
                    ); // Go back to the previous screen (home)
                  },
                  child: Text(
                    'BACK TO HOME',
                    style: GoogleFonts.poppins(
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                      letterSpacing: 1.5,
                      color: Colors.black, // Black text color
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    minimumSize: const Size(double.infinity, 50),
                    backgroundColor: Colors.deepOrange, // Dark Orange color
                    textStyle: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
