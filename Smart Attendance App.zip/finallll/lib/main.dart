import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:permission_handler/permission_handler.dart'; // ✅ NEW
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'firebase_options.dart';
import 'HomeScreen.dart';
import 'LoginScreen.dart';
import 'Attendance.dart';
import 'SignUpScreen.dart'; // Make sure this is created

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Attendance Assistance',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
      ),
      // ✅ Wrap with permission handler before showing login/home
      home: const PermissionsHandler(),

      // routes: {
      //   '/login': (context) => const LoginScreen(),
      //   '/signup': (context) => const SignUpScreen(),
      //   '/home': (context) => const HomeScreen(),
      //   '/attendance': (context) =>  Attendance(),
      // },
    );
  }
}

// ✅ New Widget: Handles BLE + Location permissions
class PermissionsHandler extends StatefulWidget {
  const PermissionsHandler({super.key});

  @override
  State<PermissionsHandler> createState() => _PermissionsHandlerState();
}

class _PermissionsHandlerState extends State<PermissionsHandler> {
  @override
  void initState() {
    super.initState();
    requestPermissions();
  }

  Future<void> requestPermissions() async {
    await [
      Permission.bluetooth,
      Permission.bluetoothScan,
      Permission.bluetoothConnect,
      Permission.location,
    ].request();
  }

  @override
  Widget build(BuildContext context) {
    // After requesting permissions, load login or home based on auth status
    return FirebaseAuth.instance.currentUser == null
        ? const LoginScreen()
        : HomeScreen();
  }
}
