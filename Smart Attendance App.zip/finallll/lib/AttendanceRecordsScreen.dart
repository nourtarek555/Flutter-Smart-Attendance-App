import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';

class AttendanceRecordsScreen extends StatefulWidget {
  final String userEmail;

  const AttendanceRecordsScreen({super.key, required this.userEmail});

  @override
  _AttendanceRecordsScreenState createState() =>
      _AttendanceRecordsScreenState();
}

class _AttendanceRecordsScreenState extends State<AttendanceRecordsScreen> {
  final List<String> _courses = [
    'Transmission and Switching',
    'Network Lab',
    'Computer System Architecture',
    'Channel Coding',
    'Network Protocols',
    'Modelling and Simulation',
  ];

  String? _selectedCourse;
  List<Map<String, dynamic>> _attendanceRecords = [];

  // Function to parse a string into DateTime
  DateTime _parseDateTime(String dateString) {
    try {
      return DateTime.parse(dateString); // Try to parse the string as DateTime
    } catch (e) {
      print("Date parsing error: $e");
      return DateTime.now(); // Fallback if parsing fails
    }
  }

  // Fetch attendance records for the selected course
  Future<void> _fetchAttendanceRecords() async {
    if (_selectedCourse == null) {
      setState(() {
        _attendanceRecords = [];
      });
      return;
    }

    try {
      // Fetch course details (startTime, endTime, dayOfWeek)
      QuerySnapshot courseSnapshot = await FirebaseFirestore.instance
          .collection('courses')
          .where('courseName', isEqualTo: _selectedCourse)
          .limit(1) // Assuming there is only one document per course name
          .get();

      if (courseSnapshot.docs.isEmpty) {
        print('No course found with the name $_selectedCourse');
        return; // Exit if the course doesn't exist
      }

      var courseData = courseSnapshot.docs.first.data() as Map<String, dynamic>;

      // Check if the course details are of correct types (Timestamp or String)
      DateTime startTime = courseData['startTime'] is Timestamp
          ? (courseData['startTime'] as Timestamp).toDate()
          : _parseDateTime(courseData['startTime']); // Try to parse if it's a string
      DateTime endTime = courseData['endTime'] is Timestamp
          ? (courseData['endTime'] as Timestamp).toDate()
          : _parseDateTime(courseData['endTime']); // Try to parse if it's a string
      String dayOfWeek = courseData['dayOfWeek'];

      // Fetch the attendance records
      QuerySnapshot querySnapshot = await FirebaseFirestore.instance
          .collection('attendances')
          .where('courseName', isEqualTo: _selectedCourse)
          .where('studentEmail', isEqualTo: widget.userEmail)
          .orderBy('timestamp', descending: false) // Fetch in chronological order
          .get();

      // Process attendance records
      List<Map<String, dynamic>> fetchedRecords = [];
      for (var doc in querySnapshot.docs) {
        DateTime timestamp = (doc['timestamp'] as Timestamp).toDate();
        bool isAttended = doc['status'] == 'Attended';

        // If attended, save the exact date and time
        if (isAttended) {
          fetchedRecords.add({
            'timestamp': timestamp,
            'status': 'Attended',
            'docId': doc.id, // Store the document ID for deletion
          });
        }
      }

      // Add "Absent" records for any class days not attended
      DateTime semesterStart = DateTime(2025, 2, 1); // Start from February
      DateTime semesterEnd = DateTime(2025, 5, 31); // End in May

      // Loop over all days of the semester to check each class day
      for (DateTime currentDay = semesterStart;
      currentDay.isBefore(semesterEnd);
      currentDay = currentDay.add(Duration(days: 1))) {
        // Check if this is the scheduled day of the week
        if (currentDay.weekday == _getDayOfWeek(dayOfWeek)) {
          bool attended = false;

          // Check if there was an attendance record on this day
          for (var record in fetchedRecords) {
            if (record['timestamp'].day == currentDay.day &&
                record['timestamp'].month == currentDay.month &&
                record['timestamp'].year == currentDay.year) {
              attended = true;
              break;
            }
          }

          // If it's in the future, don't add it to attendance records
          if (currentDay.isAfter(DateTime.now())) {
            continue; // Skip future dates
          }

          if (!attended) {
            // If no attendance record exists for this day, mark as "Absent"
            fetchedRecords.add({
              'timestamp': currentDay, // Store only the date, no time
              'status': 'Absent',
            });
          }
        }
      }

      // Sort the attendance records by timestamp (chronological order)
      fetchedRecords.sort((a, b) => a['timestamp'].compareTo(b['timestamp']));

      // Update the attendance records
      setState(() {
        _attendanceRecords = fetchedRecords;
      });
    } catch (e) {
      print('Error fetching attendance records: $e');
    }
  }

  // Helper function to map day of the week (e.g., "Monday" -> 1, "Tuesday" -> 2)
  int _getDayOfWeek(String dayOfWeek) {
    switch (dayOfWeek) {
      case 'Monday':
        return 1;
      case 'Tuesday':
        return 2;
      case 'Wednesday':
        return 3;
      case 'Thursday':
        return 4;
      case 'Friday':
        return 5;
      case 'Saturday':
        return 6;
      case 'Sunday':
        return 7;
      default:
        return 0; // Default invalid value
    }
  }

  // Function to format the timestamp
  String _formatDate(DateTime date) {
    final DateFormat formatter = DateFormat('dd MMM yyyy');
    return formatter.format(date);
  }

  // Function to format time (HH:mm) for attended records
  String _formatTime(DateTime time) {
    final DateFormat formatter = DateFormat('HH:mm');
    return formatter.format(time);
  }

  // Function to delete an attendance record from Firestore
  Future<void> _deleteAttendanceRecord(String docId) async {
    try {
      // Delete the record from Firestore
      await FirebaseFirestore.instance
          .collection('attendances')
          .doc(docId)
          .delete();

      // Remove the deleted record from the local list
      setState(() {
        _attendanceRecords.removeWhere((record) => record['docId'] == docId);
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Attendance record deleted successfully!')),
      );
    } catch (e) {
      print('Error deleting attendance record: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Failed to delete attendance record.')),
      );
    }
  }

  @override
  void initState() {
    super.initState();
    // Initially fetch attendance records if a course is selected.
    if (_selectedCourse != null) {
      _fetchAttendanceRecords();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'ATTENDANCE RECORDS',
          style: GoogleFonts.poppins(fontWeight: FontWeight.bold, color: Colors.white),
        ),
        centerTitle: true,
        backgroundColor: Colors.deepOrange,
      ),
      body: Container(
        color: Colors.pink[50], // Light pink background
        padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'SELECT COURSE: ',
              style: GoogleFonts.poppins(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            const SizedBox(height: 8),
            DropdownButtonFormField<String>(
              value: _selectedCourse,
              hint: Text(
                'SELECT COURSE',
                style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
              ),
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                filled: true,
                fillColor: Colors.white,
              ),
              items: _courses.map((String course) {
                return DropdownMenuItem<String>(
                  value: course,
                  child: Text(
                    course.toUpperCase(),
                    style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
                  ),
                );
              }).toList(),
              onChanged: (String? value) async {
                setState(() {
                  _selectedCourse = value; // Set the selected course
                  _attendanceRecords = []; // Clear the previous records when a new course is selected
                });

                // Fetch attendance records when a new course is selected
                await _fetchAttendanceRecords();
              },
            ),
            const SizedBox(height: 30),
            if (_selectedCourse != null && _attendanceRecords.isEmpty)
              Text(
                'No attendance records found for the selected course.',
                style: GoogleFonts.poppins(fontSize: 16, color: Colors.red),
              ),
            if (_selectedCourse != null && _attendanceRecords.isNotEmpty)
              Expanded(
                child: ListView.builder(
                  itemCount: _attendanceRecords.length,
                  itemBuilder: (context, index) {
                    var record = _attendanceRecords[index];
                    var status = record['status'] == 'Attended' ? 'Present' : 'Absent';
                    var formattedDate = _formatDate(record['timestamp']);
                    var formattedTime = _formatTime(record['timestamp']);
                    IconData statusIcon =
                    record['status'] == 'Attended' ? Icons.check : Icons.close;
                    Color statusColor =
                    record['status'] == 'Attended' ? Colors.green : Colors.red;
                    Color backgroundColor =
                    record['status'] == 'Attended' ? Colors.green.withOpacity(0.2) : Colors.red.withOpacity(0.2);

                    return Card(
                      margin: const EdgeInsets.symmetric(vertical: 8),
                      elevation: 4,
                      child: ListTile(
                        title: Text(
                          'Attendance on $formattedDate',
                          style: GoogleFonts.poppins(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        subtitle: Text(
                          'Status: $status',
                          style: GoogleFonts.poppins(),
                        ),
                        trailing: Container(
                          padding: const EdgeInsets.all(8.0),
                          decoration: BoxDecoration(
                            color: backgroundColor,
                            borderRadius: BorderRadius.circular(50), // Rounded corners
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                statusIcon,
                                color: statusColor,
                                size: 30, // Bigger icon
                              ),
                              if (record['status'] == 'Attended') ...[
                                const SizedBox(width: 10),
                                Text(formattedTime, style: GoogleFonts.poppins()),
                              ],
                              IconButton(
                                icon: Icon(
                                  Icons.delete,
                                  color: Colors.red,
                                ),
                                onPressed: () {
                                  _deleteAttendanceRecord(record['docId']);
                                },
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
          ],
        ),
      ),
    );
  }
}
